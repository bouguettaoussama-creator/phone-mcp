package com.phonemcp

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var hintTv: TextView
    private lateinit var tokenEt: EditText
    private lateinit var connectBtn: Button
    private lateinit var statusTv: TextView
    private lateinit var urlTv: TextView
    private lateinit var copyBtn: Button
    private lateinit var stopBtn: Button
    private lateinit var shizukuTv: TextView
    private lateinit var shizukuBtn: Button

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { ShizukuShell.bind(); refresh() }
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ShizukuShell.init(applicationContext)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        fun tv(t: String, size: Float = 15f) = TextView(this).apply { text = t; textSize = size; setPadding(0, 20, 0, 6) }
        fun btn(t: String, onClick: () -> Unit) = Button(this).apply { text = t; setOnClickListener { onClick() } }

        hintTv = tv("ألصق مفتاح حسابك في ngrok (authtoken) ثم اضغط اتصال، وانتظر قليلاً ليظهر رابط MCP.")
        tokenEt = EditText(this).apply {
            hint = "ngrok authtoken"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("token", ""))
        }
        connectBtn = btn("اتصال") { connect(prefs.edit()) }
        statusTv = tv("")
        urlTv = tv("", 13f).apply { setTextIsSelectable(true) }
        copyBtn = btn("نسخ الرابط") {
            val u = McpState.url
            if (u.isNotEmpty()) {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("mcp", u))
                toast("تم النسخ")
            }
        }
        stopBtn = btn("إيقاف") {
            startService(Intent(this, McpService::class.java).setAction(McpService.ACTION_STOP))
        }
        shizukuTv = tv("", 13f)
        shizukuBtn = btn("تفعيل Shizuku (اختياري: التحكم بالشاشة)") {
            if (ShizukuShell.binderAlive()) runCatching { Shizuku.requestPermission(100) }
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 80, 40, 40)
            listOf<View>(
                TextView(this@MainActivity).apply { text = "Phone MCP"; textSize = 24f },
                hintTv, tokenEt, connectBtn, statusTv, urlTv, copyBtn, stopBtn, shizukuTv, shizukuBtn,
            ).forEach { addView(it) }
        }
        setContentView(ScrollView(this).apply { addView(col) })

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        McpState.listener = { refresh() }

        // Returning user: connect automatically with the saved key.
        if (!McpState.running && !McpState.userStopped && tokenEt.text.isNotBlank()) connect(prefs.edit())
    }

    private fun connect(editor: android.content.SharedPreferences.Editor) {
        val token = tokenEt.text.toString().trim()
        if (token.isEmpty()) { toast("أدخل مفتاح ngrok"); return }
        editor.putString("token", token).apply()
        McpState.userStopped = false
        startForegroundService(Intent(this, McpService::class.java).putExtra("token", token))
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onDestroy() {
        McpState.listener = null
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        super.onDestroy()
    }

    private fun refresh() {
        val running = McpState.running
        val hasUrl = McpState.url.isNotEmpty()
        hintTv.visibility = if (running) View.GONE else View.VISIBLE
        tokenEt.visibility = if (running) View.GONE else View.VISIBLE
        connectBtn.visibility = if (running) View.GONE else View.VISIBLE
        stopBtn.visibility = if (running) View.VISIBLE else View.GONE
        copyBtn.visibility = if (hasUrl) View.VISIBLE else View.GONE
        statusTv.text = if (McpState.status.isEmpty()) "" else "الحالة: ${McpState.status}"
        urlTv.text = McpState.url

        val alive = ShizukuShell.binderAlive()
        val ok = ShizukuShell.permitted()
        shizukuTv.text = when {
            ok -> "Shizuku: مفعّل (التحكم بالشاشة والنظام يعمل)"
            alive -> "Shizuku: يعمل لكن بلا إذن (التحكم بالشاشة معطّل)"
            else -> "Shizuku: غير مشغّل (الأوامر والملفات تعمل، التحكم بالشاشة معطّل)"
        }
        shizukuBtn.visibility = if (alive && !ok) View.VISIBLE else View.GONE
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
