package com.phonemcp

import android.os.Handler
import android.os.Looper

object McpState {
    @Volatile var running = false
    @Volatile var url = ""
    @Volatile var status = ""
    @Volatile var userStopped = false
    @Volatile var listener: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    // Named post* (not set*) to avoid JVM clashes with the property setters above.
    fun postUrl(u: String) { url = u; notifyChange() }
    fun postStatus(s: String) { status = s; notifyChange() }
    fun postRunning(r: Boolean) { running = r; notifyChange() }
    private fun notifyChange() { main.post { listener?.invoke() } }
}
