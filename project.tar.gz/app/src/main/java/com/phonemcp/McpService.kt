package com.phonemcp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

class McpService : Service() {
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopServer(); return START_NOT_STICKY }
        if (McpState.running) return START_STICKY

        PyBridge.appCtx = applicationContext
        ShizukuShell.init(applicationContext)
        startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        wake = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "phonemcp:server").apply { acquire() }

        val token = intent?.getStringExtra("token").orEmpty()
        val domain = intent?.getStringExtra("domain").orEmpty()
        McpState.userStopped = false
        ShizukuShell.bind() // optional: no-op when Shizuku is unavailable
        McpState.setRunning(true)
        McpState.setStatus("Connecting...")
        Thread({
            try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(applicationContext))
                Python.getInstance().getModule("server")
                    .callAttr("main", token, domain, filesDir.absolutePath)
            } catch (t: Throwable) {
                McpState.setStatus("Error: ${t.message}")
            } finally {
                McpState.setRunning(false)
                McpState.setUrl("")
                wake?.let { if (it.isHeld) it.release() }
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }, "mcp-server").start()
        return START_STICKY
    }

    private fun stopServer() {
        McpState.userStopped = true
        McpState.setStatus("")
        runCatching { Python.getInstance().getModule("server").callAttr("stop") } // main thread's finally cleans up
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Phone MCP", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, McpService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Phone MCP is running")
            .setContentText("MCP server + tunnel active")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.phonemcp.STOP"
        const val CHANNEL = "phonemcp"
    }
}
