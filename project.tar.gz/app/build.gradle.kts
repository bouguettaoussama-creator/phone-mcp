plugins {
    id("com.android.application")
    id("com.chaquo.python") version "17.0.0"
}

android {
    namespace = "com.phonemcp"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.phonemcp"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
        ndk { abiFilters += "arm64-v8a" }
    }
    buildFeatures { aidl = true }
    packaging { jniLibs { useLegacyPackaging = true } } // ngrok binary must be extracted to nativeLibraryDir
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

chaquopy {
    defaultConfig { version = "3.11" }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    implementation("androidx.annotation:annotation:1.10.0")
}
