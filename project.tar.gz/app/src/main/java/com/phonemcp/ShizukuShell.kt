package com.phonemcp

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/** App-process client for the Shizuku shell user-service. */
object ShizukuShell {
    @Volatile private var svc: IShell? = null
    @Volatile private var bound = false
    private lateinit var args: Shizuku.UserServiceArgs

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            svc = IShell.Stub.asInterface(binder)
            McpState.setStatus("Shizuku shell connected")
        }
        override fun onServiceDisconnected(name: ComponentName) {
            svc = null
            bound = false
        }
    }

    fun init(ctx: Context) {
        if (::args.isInitialized) return
        args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, ShellService::class.java.name))
            .daemon(false)
            .processNameSuffix("shell")
            .debuggable(false)
            .version(1)
    }

    fun binderAlive(): Boolean = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    fun permitted(): Boolean = binderAlive() &&
        runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }.getOrDefault(false)

    @Synchronized
    fun bind() {
        if (bound || !permitted()) return
        runCatching { Shizuku.bindUserService(args, conn); bound = true }
            .onFailure { McpState.setStatus("bind failed: ${it.message}") }
    }

    fun unbind() {
        runCatching { Shizuku.unbindUserService(args, conn, true) }
        svc = null; bound = false
    }

    private fun await(): IShell? {
        if (!permitted()) return null
        if (svc == null) bind()
        var waited = 0
        while (svc == null && waited < 8000) { Thread.sleep(200); waited += 200 }
        return svc
    }

    fun run(cmd: String, timeoutSec: Int): String =
        runCatching { await()?.run(cmd, timeoutSec) ?: "error: Shizuku shell not connected" }
            .getOrElse { "error: ${it.message}" }

    fun readChunk(path: String, offset: Long, len: Int): ByteArray =
        runCatching { await()?.readChunk(path, offset, len) ?: ByteArray(0) }.getOrDefault(ByteArray(0))
}
