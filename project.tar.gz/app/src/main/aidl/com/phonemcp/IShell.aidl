package com.phonemcp;

interface IShell {
    void destroy() = 16777114; // reserved by Shizuku
    String run(String cmd, int timeoutSec) = 1;
    byte[] readChunk(String path, long offset, int len) = 2;
}
