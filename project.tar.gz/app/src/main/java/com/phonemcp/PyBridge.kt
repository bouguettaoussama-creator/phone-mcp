package com.phonemcp

import android.content.Context

/** Static entry points called from Python (server.py) via Chaquopy. */
object PyBridge {
    lateinit var appCtx: Context

    @JvmStatic fun shizukuAvailable(): Boolean = ShizukuShell.permitted()
    @JvmStatic fun run(cmd: String, timeoutSec: Int): String = ShizukuShell.run(cmd, timeoutSec)
    @JvmStatic fun readChunk(path: String, offset: Long, len: Int): ByteArray = ShizukuShell.readChunk(path, offset, len)
    @JvmStatic fun ngrokPath(): String = appCtx.applicationInfo.nativeLibraryDir + "/libngrok.so"
    @JvmStatic fun setUrl(url: String) = McpState.setUrl(url)
    @JvmStatic fun setStatus(s: String) = McpState.setStatus(s)
}
