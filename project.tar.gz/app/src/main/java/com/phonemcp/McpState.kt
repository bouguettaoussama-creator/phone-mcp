package com.phonemcp

import android.os.Handler
import android.os.Looper

object McpState {
    @Volatile var running = false
    @Volatile var url = ""
    @Volatile var status = ""
    @Volatile var userStopped = false
    @Volatile var listener: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    fun setUrl(u: String) { url = u; notifyChange() }
    fun setStatus(s: String) { status = s; notifyChange() }
    fun setRunning(r: Boolean) { running = r; notifyChange() }
    private fun notifyChange() { main.post { listener?.invoke() } }
}
