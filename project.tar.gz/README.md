# Phone MCP

Android app: open it, paste your ngrok authtoken, and get an MCP URL for your AI to control the phone
(run commands, read/write/edit files; screen control when Shizuku is enabled).

Build: push to GitHub, then Actions -> "Build APK" -> download the `phone-mcp-debug` artifact.
