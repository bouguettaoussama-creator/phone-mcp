package com.phonemcp

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

/** Runs inside the Shizuku user-service process (shell uid). */
class ShellService() : IShell.Stub() {
    @Suppress("UNUSED_PARAMETER")
    constructor(context: Context) : this()

    override fun destroy() {
        exitProcess(0)
    }

    override fun run(cmd: String, timeoutSec: Int): String {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        runCatching { p.outputStream.close() }
        val out = ByteArrayOutputStream()
        val reader = Thread { runCatching { p.inputStream.copyTo(out) } }.also { it.start() }
        val finished = p.waitFor(timeoutSec.toLong(), TimeUnit.SECONDS)
        if (!finished) p.destroyForcibly()
        reader.join(2000)
        var s = String(out.toByteArray(), Charsets.UTF_8)
        if (s.length > MAX_CHARS) s = s.take(MAX_CHARS / 2) + "\n...[truncated]...\n" + s.takeLast(MAX_CHARS / 2)
        return if (finished) "exit=${p.exitValue()}\n$s" else "timeout after ${timeoutSec}s\n$s"
    }

    override fun readChunk(path: String, offset: Long, len: Int): ByteArray {
        RandomAccessFile(path, "r").use { f ->
            f.seek(offset)
            val buf = ByteArray(len.coerceAtMost(CHUNK_MAX))
            val n = f.read(buf)
            return if (n <= 0) ByteArray(0) else buf.copyOf(n)
        }
    }

    private companion object {
        const val MAX_CHARS = 200_000
        const val CHUNK_MAX = 512 * 1024
    }
}
