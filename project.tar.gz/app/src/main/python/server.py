"""Minimal MCP (streamable HTTP, JSON responses) server for Chaquopy.
Pure stdlib: no native dependencies. All device access goes through Shizuku (shell uid)."""
import base64, hmac, json, os, re, secrets, shlex, subprocess, threading, time
import urllib.request
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from java import jclass

B = jclass("com.phonemcp.PyBridge")
PORT = 8000
MAX_OUT = 20000
TMP = "/data/local/tmp"

SECRET = ""
_httpd = None
_ngrok = None


def cut(s):
    s = str(s)
    return s if len(s) <= MAX_OUT else s[: MAX_OUT // 2] + "\n...[truncated]...\n" + s[-MAX_OUT // 2:]


# ---------------- helpers ----------------

HOME = "/"


def shizuku_ok():
    return bool(B.shizukuAvailable())


def need_shizuku():
    if not shizuku_ok():
        raise RuntimeError("This tool needs Shizuku (running + permission granted to Phone MCP).")


def sh(cmd, timeout=60):
    """Privileged shell (shell uid) via Shizuku."""
    need_shizuku()
    return str(B.run(cmd, int(timeout)))


def P(path):
    if path == "~" or path.startswith("~/"):
        path = HOME + path[1:]
    return os.path.abspath(path if os.path.isabs(path) else os.path.join(HOME, path))


def local_sh(cmd, timeout=60, cwd=None):
    env = dict(os.environ, HOME=HOME)
    try:
        r = subprocess.run(["/system/bin/sh", "-c", cmd], cwd=cwd or HOME, env=env,
                           capture_output=True, text=True, timeout=timeout, stdin=subprocess.DEVNULL)
        return "exit=%d\n--stdout--\n%s\n--stderr--\n%s" % (r.returncode, r.stdout, r.stderr)
    except subprocess.TimeoutExpired:
        return "timeout after %ss" % timeout


# ---------------- tools: work without Shizuku (app sandbox) ----------------

def run_command(command, timeout=60, cwd="", privileged=False):
    if privileged:
        return cut(sh(command, timeout))
    return cut(local_sh(command, timeout, P(cwd) if cwd else None))


def start_background(command, cwd="", log=""):
    log = P(log) if log else os.path.join(HOME, "bg.log")
    p = subprocess.Popen(["/system/bin/sh", "-c", command], cwd=P(cwd) if cwd else HOME,
                         env=dict(os.environ, HOME=HOME), stdin=subprocess.DEVNULL,
                         stdout=open(log, "ab"), stderr=subprocess.STDOUT, start_new_session=True)
    return "pid=%d log=%s" % (p.pid, log)


def _read(path):
    try:
        with open(path, "rb") as f:
            return f.read().decode("utf-8", "replace")
    except OSError:
        if not shizuku_ok():
            raise
        out = sh("cat %s" % shlex.quote(path), 30)
        if not out.startswith("exit=0"):
            raise RuntimeError(out)
        return out.split("\n", 1)[1]


def _write(path, content, append=False):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a" if append else "w", encoding="utf-8") as f:
            f.write(content)
    except OSError:
        if not shizuku_ok():
            raise
        b64 = base64.b64encode(content.encode("utf-8")).decode()
        out = sh("mkdir -p $(dirname %s) && echo %s | base64 -d %s %s" % (
            shlex.quote(path), b64, ">>" if append else ">", shlex.quote(path)), 30)
        if not out.startswith("exit=0"):
            raise RuntimeError(out)


def read_file(path, max_chars=20000):
    return cut(_read(P(path))[: int(max_chars)])


def write_file(path, content, append=False):
    _write(P(path), content, append)
    return "wrote %d chars to %s" % (len(content), P(path))


def edit_file(path, old, new):
    p = P(path)
    t = _read(p)
    if t.count(old) != 1:
        return "error: found %d matches, need exactly 1" % t.count(old)
    _write(p, t.replace(old, new))
    return "ok"


def list_dir(path="~"):
    p = P(path)
    try:
        rows = []
        for e in sorted(os.scandir(p), key=lambda e: e.name):
            st = e.stat()
            rows.append("%s %10d %s" % ("d" if e.is_dir() else "-", st.st_size, e.name))
        return cut("\n".join(rows))
    except OSError:
        if not shizuku_ok():
            raise
        return cut(sh("ls -la %s" % shlex.quote(p), 30))


# ---------------- tools: need Shizuku (screen / input / system) ----------------

def screen_read():
    out = sh("uiautomator dump %s/pm_ui.xml >/dev/null 2>&1; cat %s/pm_ui.xml" % (TMP, TMP), 30)
    i = out.find("<?xml")
    if i < 0:
        return cut(out)
    root = ET.fromstring(out[i:])
    first = root.find("node")
    lines = ["app: %s" % (first.get("package") if first is not None else "?"),
             "flags: C=clickable E=editable; coords are tap centers (x,y)"]
    for n in root.iter("node"):
        t, d = n.get("text", ""), n.get("content-desc", "")
        clickable = n.get("clickable") == "true"
        editable = "EditText" in n.get("class", "")
        if not (t or d or clickable or editable):
            continue
        m = re.findall(r"\d+", n.get("bounds", ""))
        if len(m) != 4:
            continue
        l, tp, r, bt = map(int, m)
        rid = n.get("resource-id", "").split("/")[-1]
        flags = ("C" if clickable else "-") + ("E" if editable else "-")
        lines.append("%s (%d,%d) text=%r desc=%r id=%s" % (flags, (l + r) // 2, (tp + bt) // 2, t, d, rid))
    return cut("\n".join(lines))


def screenshot():
    path = TMP + "/pm_s.png"
    out = sh("screencap -p %s; stat -c %%s %s" % (path, path), 30)
    try:
        size = int(out.strip().split()[-1])
    except Exception:
        return {"content": [{"type": "text", "text": "screencap failed: " + cut(out)}], "isError": True}
    data = bytearray()
    off = 0
    while off < size:
        chunk = bytes(B.readChunk(path, off, 512 * 1024))
        if not chunk:
            break
        data += chunk
        off += len(chunk)
    return {"content": [{"type": "image", "data": base64.b64encode(bytes(data)).decode(), "mimeType": "image/png"}]}


def tap(x, y):
    return sh("input tap %d %d" % (int(x), int(y)), 15)


def swipe(x1, y1, x2, y2, duration_ms=300):
    return sh("input swipe %d %d %d %d %d" % (int(x1), int(y1), int(x2), int(y2), int(duration_ms)), 15)


def input_text(text):
    if not text.isascii():
        return "error: 'input text' supports ASCII only; for other languages paste via clipboard/keyboard taps"
    return sh("input text %s" % shlex.quote(text.replace(" ", "%s")), 15)


def key(keycode):
    return sh("input keyevent %s" % shlex.quote(str(keycode)), 15)


def launch_app(package):
    return sh("monkey -p %s -c android.intent.category.LAUNCHER 1" % shlex.quote(package), 20)


def list_apps(filter=""):
    cmd = "pm list packages -3"
    if filter:
        cmd += " | grep -i %s" % shlex.quote(filter)
    return cut(sh(cmd, 30))


def _s(desc, props=None, req=None):
    return {"description": desc, "inputSchema": {
        "type": "object", "properties": props or {}, "required": req or []}}

S, I, BOOL = {"type": "string"}, {"type": "integer"}, {"type": "boolean"}
NEEDS = " [Needs Shizuku]"
TOOLS = {
    "run_command": (run_command, _s(
        "Run a shell command on the phone (app sandbox; set privileged=true for shell-uid via Shizuku). "
        "Working dir defaults to the app home.", {"command": S, "timeout": I, "cwd": S, "privileged": BOOL}, ["command"])),
    "start_background": (start_background, _s("Start a long-running command in the background; output goes to a log file.",
                                               {"command": S, "cwd": S, "log": S}, ["command"])),
    "read_file": (read_file, _s("Read a text file (falls back to Shizuku for protected paths when available).",
                                {"path": S, "max_chars": I}, ["path"])),
    "write_file": (write_file, _s("Write or append a text file, creating folders.",
                                  {"path": S, "content": S, "append": BOOL}, ["path", "content"])),
    "edit_file": (edit_file, _s("Replace one exact unique occurrence of text in a file.",
                                {"path": S, "old": S, "new": S}, ["path", "old", "new"])),
    "list_dir": (list_dir, _s("List a directory.", {"path": S})),
    "screen_read": (screen_read, _s("Dump the current screen UI as compact text with tap coordinates." + NEEDS)),
    "screenshot": (screenshot, _s("Capture the screen as an image." + NEEDS)),
    "tap": (tap, _s("Tap at screen coordinates." + NEEDS, {"x": I, "y": I}, ["x", "y"])),
    "swipe": (swipe, _s("Swipe between coordinates." + NEEDS,
                        {"x1": I, "y1": I, "x2": I, "y2": I, "duration_ms": I}, ["x1", "y1", "x2", "y2"])),
    "input_text": (input_text, _s("Type ASCII text into the focused field." + NEEDS, {"text": S}, ["text"])),
    "key": (key, _s("Send a key event (e.g. KEYCODE_BACK, KEYCODE_HOME)." + NEEDS, {"keycode": S}, ["keycode"])),
    "launch_app": (launch_app, _s("Launch an app by package name." + NEEDS, {"package": S}, ["package"])),
    "list_apps": (list_apps, _s("List installed third-party packages (optional filter)." + NEEDS, {"filter": S})),
}


# ---------------- MCP protocol ----------------

def handle(msg):
    mid, method = msg.get("id"), msg.get("method")
    params = msg.get("params") or {}
    if mid is None:
        return None  # notification

    def ok(result):
        return {"jsonrpc": "2.0", "id": mid, "result": result}

    def err(code, message):
        return {"jsonrpc": "2.0", "id": mid, "error": {"code": code, "message": message}}

    if method == "initialize":
        return ok({"protocolVersion": params.get("protocolVersion", "2025-06-18"),
                   "capabilities": {"tools": {}},
                   "serverInfo": {"name": "phone-mcp", "version": "0.1.0"}})
    if method == "ping":
        return ok({})
    if method == "tools/list":
        return ok({"tools": [dict(name=n, **spec) for n, (_, spec) in TOOLS.items()]})
    if method == "tools/call":
        name = params.get("name")
        if name not in TOOLS:
            return err(-32602, "unknown tool: %s" % name)
        try:
            res = TOOLS[name][0](**(params.get("arguments") or {}))
        except Exception as e:
            return ok({"content": [{"type": "text", "text": "error: %s" % e}], "isError": True})
        if isinstance(res, dict):
            return ok(res)
        return ok({"content": [{"type": "text", "text": str(res)}]})
    return err(-32601, "method not found: %s" % method)


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, code, body=b""):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _auth(self):
        return hmac.compare_digest(self.path.split("?")[0], "/%s/mcp" % SECRET)

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n) if n else b""
        if not self._auth():
            return self._send(404)
        try:
            data = json.loads(raw)
        except Exception:
            return self._send(400)
        msgs = data if isinstance(data, list) else [data]
        replies = [r for r in (handle(m) for m in msgs) if r is not None]
        if not replies:
            return self._send(202)
        self._send(200, json.dumps(replies if isinstance(data, list) else replies[0]).encode())

    def do_GET(self):
        self._send(405 if self._auth() else 404)

    def do_DELETE(self):
        self._send(405 if self._auth() else 404)


# ---------------- ngrok ----------------

_last_err = ""


def _watch_ngrok(proc):
    global _last_err
    for line in iter(proc.stdout.readline, b""):
        s = line.decode("utf-8", "replace").strip()
        if "ERR_NGROK" in s or "lvl=eror" in s or ("err=" in s and "err=nil" not in s):
            _last_err = s[-200:]


def _start_ngrok(token, domain, home):
    global _ngrok
    cfg = os.path.join(home, "ngrok.yml")
    with open(cfg, "w") as f:
        f.write("version: 3\nagent:\n  authtoken: %s\n  dns_resolver_ips:\n    - 8.8.8.8\n    - 1.1.1.1\n  crl_noverify: true\n  update_check: false\n" % token)
    os.chmod(cfg, 0o600)
    cmd = [str(B.ngrokPath()), "http", "127.0.0.1:%d" % PORT, "--config", cfg, "--log=stdout"]
    if domain:
        cmd.append("--url=https://%s" % domain)
    env = dict(os.environ, HOME=home)
    _ngrok = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
    threading.Thread(target=_watch_ngrok, args=(_ngrok,), daemon=True).start()
    for _ in range(40):
        if _ngrok.poll() is not None:
            time.sleep(0.5)
            return None
        try:
            with urllib.request.urlopen("http://127.0.0.1:4040/api/tunnels", timeout=2) as r:
                tunnels = json.load(r).get("tunnels", [])
            if tunnels:
                return tunnels[0]["public_url"]
        except Exception:
            pass
        time.sleep(1)
    return None


def main(token, domain, home):
    global SECRET, _httpd, HOME
    HOME = home
    os.environ["HOME"] = home
    key_file = os.path.join(home, "secret")
    if not os.path.exists(key_file):
        with open(key_file, "w") as f:
            f.write(secrets.token_urlsafe(32))
        os.chmod(key_file, 0o600)
    SECRET = open(key_file).read().strip()

    _httpd = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    _httpd.daemon_threads = True
    threading.Thread(target=_start_and_publish, args=(token, domain, home), daemon=True).start()
    B.setStatus("Server up on 127.0.0.1:%d, starting tunnel..." % PORT)
    _httpd.serve_forever()


def _start_and_publish(token, domain, home):
    pub = _start_ngrok(token, domain, home)
    if pub:
        B.setUrl("%s/%s/mcp" % (pub.rstrip("/"), SECRET))
        B.setStatus("Connected")
    else:
        B.setStatus("Tunnel failed: " + (_last_err or "no response from ngrok (check authtoken / internet)"))
        stop()


def stop():
    global _httpd, _ngrok
    if _ngrok:
        _ngrok.terminate()
        _ngrok = None
    if _httpd:
        threading.Thread(target=_httpd.shutdown, daemon=True).start()
