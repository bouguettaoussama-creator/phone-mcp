Gradle wrapper files and the Shizuku user-service approach are adapted from
Zafiro (https://github.com/niki914/zafiro), MIT License, Copyright (c) 2026 niki914.
